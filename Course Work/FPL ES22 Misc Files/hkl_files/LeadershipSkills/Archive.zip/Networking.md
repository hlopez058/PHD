# Networking

Networking with Shannon Oconnel
- Army brat
- Petpeeves: 
	- People who talk to just talk
	- Poelpe who are silent when they should speak up
	- Those who dont take ownership and complain about others 
- Leadership
	- Dont jump to conclusions
	- create safe environment
	- serious attitude while working








Networking meeting with Cesar Amacirella
- Set up for 


NEtowkring meeting with Jenna Pizow:
- WOrks with marketing team
- Baseline of brand awareness
- metrics : research and brand study
- Advertising agency in newyork
- Build data in tableau 
- mostly visualizing the data 
- using data studio , and has connections for platforms
- Acess database , and altyryx to join the data, build and run workflows
- Data visualization
- THe conversation can become a runaway conversation when you dont have a plan to the talk. 
[[NetworkingBook]]




Access control to our data sources 
- licensing, user management, connector administration
- interopility 

Networking with Barr Moses. 
	- MonteCarlo.io
	- June 12th 2020

Questions :
	- What is it like to be a women CEO/founder
	- Are there challenges the regular person wouldnt think about?
	- How many books do you read a month? what kind of books?

	- Preparation  to understand the background of the person you are speaking with. 
	- Be present , remeber they are human biengs too. Be genuinely curious about them.
	
	- Internal pressure, is defined for your self. 
	- Your expectations  ["The hard things about hard things" - Nobody cares that your scared or nervous, or failing]
	- Creating something from nothing (will it into existence)
	- "Pushing the boulder uphill"

	- Career VP gainsight (Customer Data platform) 0-60MM in 3 years
	- scheduled 50 coffee chats with early stage founders and investors. 
		- How did you start your company? 
		- B2B enterprise
		- capped your time to one year
		- Pick 3 ideas that i cared about 
		- Pretended like already had the business - 
			- called the business and did the work for free
			- idea related to data 
			- Paul Ghraham (Y-Combinator BLog posts)
			- steve laughlin (relate IQ) board member, was in salesforce and now for excel..
				"pull the thread until there is something there"
	- Blockchain : 2 months of no traction...

Research:
	- Article on Medium : Around Data
	- accuracy, quality, reliability, governance, access, protection, security
	- Data is a fragmented object accross the organization
	- direct people to blogposts for questions. 

Shelter in place in san fransisco
- Fundraising ()
- Hire
- Strategy/Products/Sales*
- crappy stuff (insurance)


Networking with Jim Gill 
- June 3rd 2020
- What do i ask?
- Can you help me understand how oil prices actually effect our business
	- Can youhelp me undestand the details of this quote : “Remember that as oil prices have come down, rig counts have come down in the Permian [Basin], which means there’s a lot less associated gas — which has actually helped natural-gas prices" from the perspective of renewables operators, John Ketchum, president and CEO of NextEra Energy Resources, said on an earnings call Tuesday. “We’ve seen a bit of an uptick [in natural-gas prices], especially recently.”
		- PErmian Basin 
		- associated gascomesfrom oil well
	- What are some topics that i should focus on if i want to deliver products to market effectively?
	- How did you change your approach over the years to become productive at work?

- in leaderhsip you dont have ot be the expert'
- WHat would todays jim robo tell a 30 year old jom robo
- Given everything you have seen int he workplace in 10 years..what do you think in next 10 years?

Networking with Jim Robo
- June 19 2020


Cover Letter:

Short Bio:
Hector Lopez, Technology Leader , FPLES IT
NextEra Energy Inc. 2013-2020

I am an engineer that dreams of designing space ships, robots, and smart cities. My role models where Jesus Christ, Leonardo DaVinci, and Albert Einstein. My hero, was my Father. He received a  scholarship from the president of Dominican Republic to attend UM. He graduated with honors in electrical engineering. He then served in the military. His love for education and hard work inspired me to pursue engineering. 

As a college student I was active in the community by mentoring in robotics competitions. I served on the board of professional engineering clubs. I even started a robotics club. My most interesting accomplishments where learning Japanese,  and competing in Juijitsu tournaments. I earned several scholarships and interned at GE as a programmer and test engineer. 

In 2009 the state department approved a $2B sale of Raytheon's patriot missile systems to the U.A.E. . I was fortunate to graduate the same year and land a role as a test engineer at Raytheon. I worked on retrofitting out-dated missile systems with digital components. Over time I gained skills in advanced software development and cybersecurity. I enjoyed the environment because it was stimulating and exciting. It was hard work with a tinge of secrecy that made an impact. After some time, I grew uncomfortable with the culture. There was political tensions, espionage, and military over-reach during wiki-leak scandals. After four years I moved to a research and development facility in Watertown MA..

I helped an eccentric nuclear physicist develop a radiation dosimeter for the DHS. We collaborated with researchers from MIT, and Lincoln Labs. I helped engineer a working prototype from mechanical, to electrical to software components. We developed novel forms of encrypted communication for military use. We implemented machine learning algorithms to identify different radiation source. We created custom silicon devices to reduce form factor. We even built a manufacturing process to grow crystals and assemble the device.  

I became home-sick and returned to South Florida. I was then married to a brilliant engineer, Judith Lopez (who now works for NextEra Energy as well). One of my first opportunities in Florida was through our IT department. I began my career at NextEra Energy working for a 30 year veteran of the company, IT Director, Jay Brown. I helped him develop energy management software. We  delivered software solutions the the trade floor. He was a stoic leader that embodied the values of the company until he retired a few years later. 

I then moved on to PGD working as a controls engineer for another great friend and leader, Michael Scott. In a world of lofty goals and constant innovations, he showed me the practical value of saying "No". It was ironic but that lesson helped me to become very prolific in my career. I assisted in engineering construction projects. I traveled around the country. I even integrated some of our first battery sites. One of my favorite memories was working on a wind turbine controller up-tower in the middle of winter. I also collected four patents and a masters degree during that time. I was then asked to join an IT team to assist them in integrating data from our generating assets. 

I jumped at the opportunity to lead a team of data engineers tasked with migrating PGD's IoT data to the cloud. I leaned on my mentors and technical training to build my leadership style. I read books and attended feedback sessions. I enjoyed strategizing with the team to solve problems together. It was a humbling experience to watch the team mature and grow. At the start of the project my first child was born. After a few years of hard won success and the growth of a wonderful team, I was ready to hand over the mantle to my successor so I could refocus on family.

My most recent chapter has been a pivot into the world of customer services at FPLES. I have a desire to grow my commercial skills so that I could better design and create products that real customers would be willing to pay for . I followed my mentor, Christine Donayri, and role-model, Troy Rice into a technology leadership position for FPLES IT.  I have been working to elevate their data management strategy and drive emerging technologies. 

As I continue to grow in the organization I am astonished at the class and quality of people I work with. The culture has kept me engaged and the technical challenges are rewarding. I am now a PhD candidate researching smart home technologies as they relate to the energy sector. I still dream of space ships, robots, and smart cities but NextEra's future is even more exciting. I think about Robert Noyce's company (Intel) and how they perfected the transistor technology. That led to a technological revolution in silicon valley. I like to think we are laying the same groundwork for a new revolution in energy technology. Today, being part of a legacy like that inspires me.




Questions :


- Do you have a unique approach to divide your time and attention across topics like growth, run-the-business, partnerships, or long term strategy? 
- Considering success and failures of recent acquisitions, how do you decide between build, buy or ally? 
- What is an emerging technology that you beleive will directly benefit nextera when it completes the hype cycle?
- It seems as if innovation is in the process of bieng "bottled" , How do you see the role of innovation leaders in the company evolving ?


- What is the most impactful book that you have read that helped you in your career or leadership strategy? 
- Can you name a person who has had a tremendous impact on you as a leader ans what specific steps did you take to establish and grow that relationship?
- What are the traits that you admire in your leadership team? 
- What’s the biggest risk you’ve ever taken?
- What advice would today’s Jim Robo give to younger jim robo? 































Easy Questions:
	- What are the best books you have read that have impacted your career or performance on the job?
	- What are your sources for continued education? Is on the job experience the best for a CEO role or do you seek out any research to help? 
	- What is your fondest memory of GE?
	

	Hard Questions:
	-  As a company we seem to continue to build on the  wind,solar and storage trifecta, ( commiting $1B in storage for 2021) , is growth through construction and operation the best driver for growth in this industry? and how long can we keep it up, is there a point of diminishing returns or saturation?
	-  The focus on Intellectual property, artificial intelligence, and advanced operational software platforms has elevated the company to become not just an energy company but also a strong technology company. But as an energy company constrained to regulations, liabilities and legacy infrastructure, we are limited in the rate of our technology growth. Is there consideration that a tech giant (i.e. google or amazon) may be better suited to enhance our energy business than what we could grow organically?
	- Gexa operates on thin margins and specializes in customer acquisition similar to FPLES. As services provided by FPLES begin to expand out of the FPL territory are there opportunities to pair the two copmanies? Is there a benefit from combined operation? Are there nuances to why they have remained seperate?
	-	Companies focused on providing consolidated solutions to customers like IBM,ATT, Amazon, Google, etc. now more than ever have lower barriers to "steal" offerings by investing in them internally. How do we choose who to partner with ? What makes an ideal corporate partner that we can go to market with?
	


- BUILD:
	-  As a company we seem to continue to build on the  wind,solar and storage trifecta, ( commiting $1B in storage for 2021) , is growth through construction and operation the best driver for growth in this industry? and how long can we keep it up, is there a point of diminishing returns or saturation?
	-  The focus on Intellectual property, artificial intelligence, and advanced operational software platforms has elevated the company to become not just an energy company but also a strong technology company. But as an energy company constrained to regulations, liabilities and legacy infrastructure, we are limited in the rate of our technology growth. Is there consideration that a tech giant (i.e. google or amazon) may be better suited to enhance our energy business than what we could grow organically?


- BUY: 
	- Gexa operates on thin margins and specializes in customer acquisition similar to FPLES. As services provided by FPLES begin to expand out of the FPL territory are there opportunities to pair the two copmanies? Is there a benefit from combined operation? Are there nuances to why they have remained seperate?


- Two acquistions Jacksonvile authority (Jea) declined, because the city of jacksonville said no, even when we where going to take on the debt. (JEA)
	- Challenging environment to buy and acquire companies.
	- GEXA is a thin margin business, (customer acquisition), are you pairing with FPLES services?
	- Growth in FPLES seems to stretch out to other boundaries. 
	- Can they benefit from combined operation?
- ALLY:
-	Companies focused on providing consolidated solutions to customers like IBM,ATT, Amazon, Google, etc. now more than ever have lower barriers to "steal" offerings by investing in them internally. How do we choose who to partner with ? What makes an ideal corporate partner that we can go to market with?
-	
-	When making a decision to partner with a company from another domain like (ATT , Amazon or Goolge ) ther
	- Who are the ideal partners that we can go to market together?
	- How do we distinguish allies between "frenemies"
		- i.e. Googles ability to get into energy
		- AWS to get into IoT Energy and generation
	- They are consolidating services, so how do you pick who we ally with?
- EBITDA , definition..

- How do you grow millions (which one is most importnat to you?)
	- Build up on success (generation, equity,) build whats working
	- Buy companies to build
	- Ally with companies where it makes sense
- portfolio adivce..
	- any energy stocks
	- what does it look like?
	- WHat are the indicators of a healthy business in the stock market?
	- WHat are the flags for removing money from a busine in th stock market
	- WHat is your investment rule set?
- WHat books do you read , and how often?, WHat books have made a lastin impact
- WHat the difference between long life career or expoure to other companies?
- Agent of Exponential Change
- How do i make friends that are millionaires
- Education 
	- How od you continue to educate yourself in a world of many choices?