Cheeky Chompers :
Assets :
1. First movers advantage
2. large baby market
3. low cost of product
4. fashionable
5. 2 moms
6. teething is a need
7. safety
8. blueocean
9.retailers
10. distributor
11. dribble bib..
12. style 
13. lifestyle branding
14. looking at an upsell
15. quality

Community
Awards
Happy customers
Patents
Design
Dragons Den



- You must control the experience
- Focus on expereince of "joy for mothers and kid safety"
- Focused on "data"
- dont sell until you can control the expereience


From Jane He to Everyone: (1:38 PM)
hejanew@gmail.com
From Me to Everyone: (1:38 PM)
hlopez058@gmail.com