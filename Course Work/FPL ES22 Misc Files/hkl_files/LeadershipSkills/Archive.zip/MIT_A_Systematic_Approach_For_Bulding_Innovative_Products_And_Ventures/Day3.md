
Beach Head Market:

Is your BHM sharp enough?

- do you have the same product for everybody?
- same full life use case (FLUC)
- same qualified value proposition
- next 10 customers need to be homogenous and buying the product
 - if they are not buying it , go back and refine the end user
 - know if they would buy it
 - make the decision and sales technique the same for each person
- Need large TAM 
- Persona development (find watering holes and proxy products)
- other

Win customer over with current product , and then sell them a new product.
- value customer relationship over current product
- move the current product to another market segment
- dont build a new product for a new market
- find a careful market expansion