


Value Proposition:
- Simplified troubleshooting of industrial systems
- Lower learning curve for engineers
- 

Core:
- Cross platform
- User Experience
- Legacy Support
- PLC logic for performance monitoring


Deployments for 
Market Segmentation
- 

What drive my customer
M.Scott



As Is State:

Possible State:


Mesaging: 
- How do you message the product to this persona?
- high quality product 
- feel like they are getting a deal
- cheap, valuable, ease of use, reliable
- focused support 
- team of people to support product
- 


Recurring Revenue
-



Customer Pain :

- Multiple SCADA platforms come with different configurations
- Different ways to decipher error codes
- Multiple devices on a control network need mapping
- Sensitive IP information of devices needs to be recorded to access the devices
- Testing multiple endpoints for connectivity
- Protocol translators can introduce errors in configuration
- Interconnected devices can cause ambiguous logs
- Legacy software can have bugs like memory leaks 
- Rebooting of SCADA hosts can cause incremental damage
- Accumulated logs can create low disk space
- Difficulty in synchronizing errors across multiple hosts becuase of local timestamp synchronization issues
- New devices with different protocols need to be integrated with older devices on same network
- Decompiling SCADA software for bugs
- Expensive SCADA software that must continue running on older operating systems can not support modern tools
- PLCs do not have a obvious performance metrics to monitor , requires added code
- Working with data and non-data communication protocols (i.e. Modbus v.s. a current signal between 4~20mA)
- Black swan anomolies that occur without any repeatability
- Data not captured when errors occured
- Recreating errors is not viable 

the controls engineer that now needs to learn how to find the service that needs to be rebooted for some random version of the GE scada installed on some windows machine at some IP address
​[2:15 PM] Lopez, Hector
    So he downloads or builds his own tools to maintain it.. maybe he gets a packet sniffer like wireshark to make sure his modbus bits are there
​[2:15 PM] Lopez, Hector
    or he downloads a network scanner to find the device connected on the IP address
​[2:16 PM] Lopez, Hector
     or maybe he sets an email alert on a PI signal that checks for the low disk space
​[2:16 PM] Lopez, Hector
    or he logs in and copies and pastes the logs from a turbine PC 
​[2:17 PM] Lopez, Hector
    or has to sniff through a bunch of events in windows eventviewer to track down when the computer was rebooted
​[2:17 PM] Lopez, Hector
    all of these things are like observability problems that are solved in the cloud software
​[2:17 PM] Lopez, Hector
    so it has yet to enter teh ICS world.. we just do all this stuff manually


