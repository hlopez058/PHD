## Welcome, Overview & What is Disciplined Entrepreneurship

Bill Aulet :
- Used to be part of IBM

Entrepreneurship can be taugt, and you can be one.
- People are born wired to survive.

Entrepreneurship :
SME :
- Small Medium Enterprise
- Local Market Focus
- Restaurants , Dry Cleaners, Services
- Change in time is short
- Linear growth (capped)
- Less investment Required
- Family owned solution

IDE:
- Innovation Driven Enterprise
- Global Market Focus
- Products w/ Innovation at Core
- change in tie is long
- valley of death(no guarantee)
- Exponential growth
- A lot of investment required

Innovation
- Commercialization + Invention/Ideas/Patents
- We would need Hacker + Hustler
- But you would need the invention and the commecialiation - Clock Speed!
- You need to itterate much faster!

MYTHS:
1. Dont be an individual entrepreneur
    - More founders -> More success
    - Data says that it is a team sport
    -
2. Entrepreneurs are not geniuses :
    - Obessesion on the problem - and becoming responsive to the space
    - Its not about how smart you are
    - figure out what you want to do and do it better than anyone else in the world
3. Entrepreneurs do not take risks :
    - they only take risks 
    - There are risks that you should take
    - must take risks on unfair advantages
    - there is no place that will not hav risks
    - take informed risks

- Entrepreneurs succed at 75% now
- Level of discipline greater than any others
- change the rules of the game and make strength a weakness
- singel most over-rated thing is the original idea
- idea is where you start, but its not right, execute in a discipline way, with a great team
- 1% inspiration , 99% perspiration
- its not a science its a practice/craft
- embrace a hard journey (Spirit of Pirate / Execution of a Navy Seal)

Its not a linear process to create a company. 

- Command and control model is not as dyanmic as distributed community of startups that can help together. 
- Be part of a community of startups to build your own groups



## Overview of DE in Action

## Who Is Your Customer? Market Segmentation and Beachhead Market Part I

## Who Is Your Customer? Market Segmentation and Beachhead Market Part II

## Doing Good PMR

## What Can You Do for Your Customer?

## Wrap-up/ preview of Day 2

