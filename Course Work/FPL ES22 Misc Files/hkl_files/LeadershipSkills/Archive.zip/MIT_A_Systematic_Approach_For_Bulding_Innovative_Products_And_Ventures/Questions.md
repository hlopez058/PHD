1. Should we use marketing (naseem mentions it is not anti-fragile)
1. Should we invest in marketing with corporate entrepreneurship?

2. If my invention is very valuable to the customer can i reduce investment in commercialiation?

3. Should my product be anti-fragile?

4.How do you choose the “Who” ? (Your influence, Your skillset, Your reach?)

Cant I just make an invention that the customer reallllly needs and reduce my investment in commercialization? (According to your formula it would be the same right?)

5. Should we distinguish between a captive customer paying you money for a business or a customer with choices paying you money to define a business?

What happens when its not so drastic? Usually the difference between the Volvo and Lamborghini is a gradient. What if it was to charge her for parking on the lot?