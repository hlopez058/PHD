- Observability platformo for ICS
- 

How to build an integration with Datadog:
Wonderware :
- read in the logs, 
- read in the uptime metrics of each connection
- read in the logged in users
- read in the host metrics
- monitor the wonderware/ge/siemens scada services on the host
- create a network map with "control devices"
- 



Market Expansion options :
1. Fireball tool for the team to login 
2. Deployment of code for bachmann
3. DCOM setting fixer
4. Device mapping of data flow
4. 

Freemium to premium price model

SCADA Engineers ->