# Step 1

## Reason d'Etre
### Why Are you in Buiness:
#### Mission: 
- Make industrial control systems easy to manage
- Make it easy to maintain industrial control systems through observability 
- Observability solutions for industrial control systems
- reduce the time to identify problems in an industrial architecture

#### Passions:
- Technology
- Software
- Business
- Engineering
- Renewables
- Control Systems
- SCADA operations

#### Values:
- Faith and family is at the center of every decision.
- Do to others as you would have others do to you.
- Seek respect by gaining trust.
- Gain trust through service.
- Serve others by fulfilling thier needs.
- Know the needs by knowing the person.
- Everything we plan must have a season, a balance and a place. 
- Stop, have fun, seek peace and enjoy the cherry blossoms.
- Not in the marketing business, in the word of mouth business
- Spirit of a pirate, execution of a navy seal

#### Initial Assets:
- first mover
- subject matter expert
- relationship with customer
- experience with control systems
- access to PLC test bench
- relationship with vendor
- licensed software for testing
- ecosystem of integrations
- understanding of legacy support

#### Initial Idea:
Data observability software for Industrial Control Systems (ICS) that combines multiple vendor/freeware tools into a single solution.

Pain : 
SCADA solutions focus on the operation and monitoring of the machine, many tools are built to monitor the health of the particular vendors SCADA system. As users begin to manage more than one of these systems additional infrastructure tools are required. Eventually users who manage the SCADA systems must become skilled in network tracing, hardware faults, event tracking, log parsing, and more to be able to troubleshoot critical faults, memory leaks, or cyber threats. Solutions provided by vendors are often focused on SCADA administration but do not provide holistic support across a users entire architecture.

Solution:
The idea is to bring application performance monitoring (APM) solutions designed for cloud resources to the isolated industrial controls domain by focusing on legacy system compatability, integrations with industrial protocols, and common lessons learned by the industry. 

Integrations with Agents:
- Custom build for monitoring and reading metrics from vendors like :
 - Wonderware
 - GE Wind SCADA
 - Siemens WPS

The key features are :
1. UX 
2. Network Map/Tracing
3. ICCP Traffic
4. 
- Wireshark (Network Packet sniffing)
- Service Monitors
- Protocol Translators
- Software Decompilers


# Step 2

## Initial Market
### Who is your customer?

#### Beachhead:
- NextEra Controls team
- Midsized renewable energy generator/operator companies
- North american market


#### End User Profile:
- Generator/Owners or plant owners
- Running Energy Management Services
- Users who manage multi-platform Industrial Control Systems
- Users with different industrial technologies or sites

#### TAM:

About 2000 wind/solar farm operators in North America.
- Managing sites that require energy management systems
- North American
- Small-Medium Sized 
- (100-500 employees)
- (30M-300M Revenue)
Assuming a subscription fee of : $1000/yr 
North American TAM : $2,000,000M/yr

Targeted TAM (1st 10 customers) : 


#### Persona:

End User Persona 1  : Peterson Skope
- Senior/Principal Engineer
- late 20's early 30's 
- loves programming PLCs / "idea of programming"
- straight A's in highschool
- drive a motorcycle
- doesnt do nightclubs
- likes photogrpahy
- hes into math physics and science
- browses PLC forums
- sci-fi movies
- high loyalty to the job
- takes pride in his work
- works late hours
- arrogant , somewhat pretentious
- he doesnt live at home
- very independent thinker
- question everything, and not take sides
- opinionated
- interested in immature hobbies
- disposable income little responsibilites at home
- online/console gaming
- visual learners
- like to solve hard problems quickly
- ambituous , entitled, looking to feel accomplished
- studied hard at school , dont want to retrain a new skill
- would like to get wins in this stage of life
- buy toys, have fun , and grow in social status
- Likes apple but carries around a window machine

End User Persona 2 : Frank Straight
- 35+ years of experience
- male, overweight
- middle age to senior
- 40-70
- Ran a business
- Has a large family with grandkids
- Into writing Sci-Fi novels
- Goes to renaissance fair
- Like turkey legs, beef jerky, bbq
- Connissuier of beers 
- Wears similar sweater everyday
- Uses glasses
- Very roundabout way of speaking
- Like to tell stories
- knowledgable of different scada platforms
- Programmer in ancient software languages
- Always has an opinion (opinionated)
- Carries a lot of influence
- Has worked on many different hardware products
- Had a commodore 64
- Searches for trivia on the internet
- Saves software on CD's and USBs as backup
- Does not like/believe in cloud technologies
- Hates apple or loves apple (either one extreme)
- Seems to have encycolpedic knowledge on every historical technological topic
- Adverse to change 
- Quick to point out negatives
- Carries a notebook/trapper keeper
- Eats the same lunch routine every day
- Wife takes care of cloths and other essentials
- A bit absent minded
- Likes to mentor , hard to manage
- Is a fire fighter and has tirbal knowledge
- Enjoys bieng the one who has the answers
- Can get jealous of new people/ideas when not involved
- Debbie downer in team settings
- Reads FOX news
- Reads Fantasy novels or Detective
- Computer science background but no higher level education
- Possible achieved MBA or some other Certificate
- Possible Scrum master or PMP
- Really enjoy talking about some esoteric solution/environment

Econmic Buyer Persona : Michael Shrute
- Middle management for a long period of time
- Very technical compared to peers
- Has worked for some big company like GE or siemens
- Long tenure at a large org
- 25+ years of experience
- White Middle aged male
- 40-60s
- takes pride in his job
- MBA from aurburn
- Electrical Engineer 
- Loves his new born child
- Shrewed businessman
- Stickler for details
- Whears white button down
- Manages 5-8 people
- Has tried to brew his own beer
- Use to have his own business
- Considers his decisions to be practical
- Thinks hes funny
- Has some akward social cues
- Can be freindly
- Very knowledgable
- Interested in making real connections
- Politically correct
- Honest to a fault

#### 1st 10 Customers:


1.) NextEra Energy Resources
U.S. Wind Projects: 99
Operating Capacity (MW): 13,072.55

NextEra Energy, Inc. (NYSE: NEE) is a leading clean energy company with consolidated revenues of approximately $17.0 billion, approximately 44,900 megawatts of generating capacity, which includes megawatts associated with noncontrolling interests related to NextEra Energy Partners, LP (NYSE: NEP), and approximately 13,800 employees in 27 states and Canada as of year-end 2014. Headquartered in Juno Beach, Fla., NextEra Energy’s principal subsidiaries are Florida Power & Light Company, which serves approximately 4.7 million customer accounts in Florida and is one of the largest rate-regulated electric utilities in the United States, and NextEra Energy Resources, LLC, which, together with its affiliated entities, is the world’s largest generator of renewable energy from the wind and sun. Through its subsidiaries, NextEra Energy generates clean, emissions-free electricity from eight commercial nuclear power units in Florida, New Hampshire, Iowa, and Wisconsin. NextEra Energy has been recognized often by third parties for its efforts in sustainability, corporate responsibility, ethics and compliance, and diversity, and has been ranked in the top 10 worldwide for innovativeness and community responsibility as part of Fortune’s 2015 list of “World’s Most Admired Companies.

2.) Invenergy LLC
U.S. Wind Projects: 47
Operating Capacity (MW): 6,885.93

Invenergy and its affiliated companies develop, own, and operate large-scale renewable and other clean energy generation and storage facilities in the Americas, Europe, and Asia. Invenergy’s home office is located in Chicago and it has regional development offices in the United States, Canada, Mexico, Japan, Poland, and Scotland. Invenergy and its affiliated companies have successfully developed more than 20,400 megawatts of projects that are in operation, construction or contracted, including wind, solar, and natural gas power generation and advanced energy storage projects.

3.) EDP Renewables North America LLC
U.S. Wind Projects: 49
Operating Capacity (MW): 6,518.20

EDP Renewables North America LLC (“EDPR NA”) and its subsidiaries develop, construct, own, and operate wind farms and solar parks throughout North America. Headquartered in Houston, Texas, with 45 wind farms, five solar parks, and 13 regional and development offices across North America, EDPR NA has developed more than 6,200 megawatts (MW) and operates more than 5,600 MW of renewable energy projects. EDPR NA is owned by EDP Renováveis, S.A. (EDPR).

4.) Avangrid Renewables
U.S. Wind Projects: 59
Operating Capacity (MW): 6,276.84

Avangrid, Inc. (NYSE: AGR) is a diversified energy and utility company with approximately $32 billion in assets and operations in 27 states. The company owns regulated utilities and electricity generation assets through two primary lines of business, Avangrid Networks and Avangrid Renewables. Avangrid Networks is comprised of eight electric and natural gas utilities, serving approximately 3.2 million customers in New York and New England. Avangrid Renewables operates more than 6 gigawatts of owned and controlled renewable generation capacity, primarily through wind and solar, in 22 states across the United States. AVANGRID employs approximately 6,800 people.

5.) EDF Renewable Energy
U.S. Wind Projects: 44
Operating Capacity (MW): 5,011.63

EDF Renewables North America is a market leading independent power producer and service provider with over 30 years of expertise in renewable energy. The Company delivers grid-scale power: wind (onshore and offshore), solar photovoltaic, and storage projects; distributed solutions: solar, solar+storage, EV charging and energy management; and asset optimization: technical, operational, and commercial skills to maximize the performance of generating projects. EDF Renewables’ North American portfolio consists of 10 GW of developed projects and 10 GW under service contracts. EDF Renewables is a subsidiary of EDF Renouvelables, the dedicated renewable energy affiliate of the EDF Group.

6.) Tradewind Energy, Inc.
U.S. Wind Projects: 18
Operating Capacity (MW): 4,035.51

Tradewind Energy is one of the largest wind and solar project development companies in the U.S. They deliver long-term power projects that tap into nature’s resources to produce sustainable energy for our nation. Tradewind Energy has earned a reputation for innovation in the market, for a highly skilled and passionate team, and deeply held respect for the people, environment, and communities where they develop projects.

7.) E.ON Climate & Renewables North America
U.S. Wind Projects: 22
Operating Capacity (MW): 3,901.83

E.ON Climate & Renewables North America (E.ON) is a leading renewable energy company headquartered in Chicago, IL, with wind headquarters in Austin, TX and global solar headquarters in San Francisco, CA. E.ON Climate & Renewables North America is a subsidiary of E.ON SE, one of the worlds™ largest energy companies, and the largest investor-owned utility in the world. E.ON possesses the financial strength, expertise and commitment to meet the growing demand for safe and reliable renewable energy. With almost 300 U.S. employees, they are creating tomorrows energy sources today! Tapping renewable energy sources offers enormous alternatives, both from a business perspective and for the environment. E.ON Climate & Renewables has already invested $12.3 billion in renewable energy projects and will continue to expand the share of renewable energy in E.ON™ power generation portfolio. E.ON has thus taken a leading role in developing renewable energy sources worldwide.

8.) Pioneer Green Energy
U.S. Wind Projects: 21
Operating Capacity (MW): 3,563.07

Pioneer Green Energy is a developer of utility-scale wind and solar projects across the U.S. The company has developed over 800 megawatts of renewable energy projects that are either operating or currently under construction, including 95 megawatts of solar photovoltaic projects. Additionally, its principals have helped develop over 2,700 megawatts of currently operating wind projects owned by leading industry players. Pioneer specializes in bringing to market high-value projects driven by in-depth transmission analysis. The company is headquartered in Austin, Texas.

9.) RES Americas
U.S. Wind Projects: 20
Operating Capacity (MW): 3,301.72

Since 1997, RES has been providing development, engineering, construction, and operations services to the utility-scale wind, solar, transmission, and energy storage markets across the Americas. The company employs more than 500 full-time professionals and has over 8,000 MW of utility-scale renewable energy and energy storage projects and has constructed more than 700 miles of transmission lines throughout the U.S., Canada, and Chile. RES’ U.S. corporate office is located in Broomfield, CO with regional offices located in Austin, TX, Minneapolis, MN, Old Saybrook, CT, and San Francisco, CA.

10.) Apex Clean Energy
U.S. Wind Projects: 17
Operating Capacity (MW): 3,172.15

Apex Clean Energy builds, owns, and operates utility-scale wind and solar power facilities. Apex was the U.S. market leader in 2015 and has brought nearly 1,700 MW online over the past two years. With a team of over 200 professionals and the nation’s largest wind energy project pipeline, Apex is one of the leaders in the transition to a clean energy future.

Bonus 🎉🎉: Lincoln Clean Energy
U.S. Wind Projects: 16
Operating Capacity (MW): 3,050.00

Lincoln Clean Energy (LCE) is a leading developer of U.S. wind and solar projects with offices in Chicago, IL and Austin, TX. Since 2011, LCE has developed over 1,000 megawatts of renewable power projects in California, New Jersey, and Texas. In December 2015, LCE was acquired by and became a portfolio company of I Squared Capital, through its ISQ Global Infrastructure Fund, and announced plans to deploy $250 million in equity investments through 2018. I Squared Capital is an independent global infrastructure investment manager focusing on energy, utilities, and transport in North America, Europe, and select high growth economies.

 
1.Pattern Energy
2.Apex Clean Energy
3.Terra-Gen Renewable Energy
4.Tri Global Energy
5.PPM Energy
6.Horizon Wind Energy
7.Pacific Hydro
8.BluEarth Renewables
9.BlueWave
10.Naturener







Who are the people we need to target?

Define Terms:
Application Reliability :
 - Keeping apps running based on the vendor specific reccomendations
 - Software is configured based on vendor spec's
 - Long term contracts
 - Warranty on operation of the application
 - Patches available (GE upgrades)
 - Vendor support 24/7
 - SLA's on the app running 
 - Learning/Training invested in App usage by the team

Infrastructure Reliability :
 - Mostly dependent on custom architecture
 - Networking / Security and other systems



 