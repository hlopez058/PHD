# Why they wont give you the secret to thier success ; An engineers journey through a fortune 200 company 
## Preface 
- My engineering background and discipline, style of work , historical experineces with large orgnaizaitons
- I am an abnormal engineer with a bent towards art. 
- Influences are my Father , Davinci and Einstien.
- Worked as an intern in design labs, became self taught coder in highscool

## Intro:
- A 'lunch and learn' from a charismatic leader challenging employees to seek out advice from people
- Challenged by a colleague to face my fear of networking
- Embracing leadership through this process
- Opportunities creted
- Inisghts gained
- Experience brought a desire for more
- Converting the goal of networking to a habit that generates personal growth
- This is not an inclusive understanding , but a survey of what has been learned and observations of growth
- bieng able to work with exccentric know-it-all engineers became a skill growing up ,
	- Partnerships with excentric people is not easy, and this is a skill that if you think you have can position you for some success in corporate leadership
		- steve job and wozniack
		- bill gates and paul allen
		- Elon musk, peter thiel
		- sergey brin and larry page
		- mark zuckerberg and Eduardo Saverin

## Topics
#### How i Work
- The "solution net"
	- I am very creative and have always admired the idea of"rebels" thinking outside of the box. 
	- When I see a difficult problem i see it as a riddle and immediately , sub-conciously, run through the paces
		- Have i seen anything like it?
		- What is the pattern i recognize?
		- What are the missing variables?
		- What are the forces involved?
		- What is the scope?
	- I then try to push the problem through transformations and look for chinks in the armmor
		- Segmentation,Invert, Multiply, Expand, Contract, Clone, Magnify, Blur, Sharpen , Contrast
	- After an inital "gut" feeling does not provide an anser sufficiently elegant , I activley engage into logic
		- What is the Conflict I am solving?
		- All problems are just series of contradicting constraints (It needs ot be BIg, but also Small)
		-  I identify the contradiction and look for solutions in my "novelty bag"
			-  A novelty bag holds my list of novel ideas i have come across int he past.
			-  bieng an engineer i see alot of these novelties in the form of solutions to similar contradictions
				-  When there is a need for someting to be Large and Small at the same time i think of these two contradictions existing in the same 'space', the spatial dimensions of x,y,z. I need another dimension to resolve this contradiction, and when viewing pervious solutions they show that the noveltyhere is to utilize the time dimension , by transforming the object over time to achieve the simultaneous ability to be large when need to be large at some time and small when needed to be large at some other time.
				-  The understanding of when and how to use other dimensions in the problem comes from patterns of similar problems highlighting the "holes" in the questions. 
				-  Most riddles are just incomplete questions.
					-  By finding the set of novel solutions that solve the contradiction in the riddle , you can highlight the missing information in the riddle by seeing the relationship between novel solutions and thier other associated riddles  
					-  The associations and the pattern matching is a natural tendency.
					-  The unique thing is the ability to have a robust list of novel soltuions tied to a fleshed out problems
			-  Defining my Terms when it comes ot engineering:
				-  I thought finding a mathematical 'solution' to a problem was how people solve problems.
					-  the real-world is a noisy place where contradictions force you to choose the "best" assumption
					-  no clear answers in the real-world.
					-  So what is problem solving if its not the pure answer to the ideally formalied question?
				-  Problem solving, is not finding an answer to that problem, its  linking previously solved problems and providing the best answer that fits the constraints
				-  Solutions are the answer to a problem that satisfies a human need 
					-  humans need different things, at different times, for different reasons
					-  The riddles begins trying to understand the need, this requires a bag of novlety that is human oriented not system oriented.
				-  Engineers collect a novelty bag of physics, scientific theory, mathematics, phenomonons, statistics, and complex forces 
				-  Engineers rarely collect a novelty bag of human suffering,human desires, mental bias, psychological phenomenon, sociological forces , etc. 
				-  The novelty bag is more difficult to fill with human oriented soltuions since the science is not as concrete and relies on "art" forms that change person to person
#### Stigma
- The project manager with little to no expertise performing 
#### An Introverted Engineer's approach to networking
- My interview list
- Ambitously meet people i dont have anything in common with
- Search for interesting people
- Start with my comfortable peers and mentors
#### My Approach
##### How to reach out
###### Create a networking email
- I copied the same simple format the expensive staffing companies use to reach out to me on linked in , with some slight variation
	- Hello, (persone name)
	- I am  (position in company, title, or relationship with someone they know)
	- I am interested in (persons work/ or dept)
	- Would you be available to talk more about (topic of interest ) ... over some coffee 
- keep it simple, direct and informal
- Even when reaching out to an executive, less seems to be more. They will respond with someone 'cc' that can help schedule a time for you. 
- Run the email by someone close to you to make sure its not to "wierd"
###### Prepping the right tools
- The power of the notebook and pen
	- A notepad with questions, can be powerful to solidify a good point in the conversation it can anchor good ideas and keep you on track with an outline.
	- It can be a crutch and used incorrectly create a barrier between two people. (especially for fidgety and nervous introverts)
###### Logistics
- "Buying coffee", is a bad ice-breaker
	- Purchasing somehting for a peer or external vendor is ok, but for most companies buying something for a superior is not policy
	- waiting in line while tracking to make a first impression becomes very awkward
	- I found meeting someone for the first time is easier when its not complicated with this process , on the second meeting coffee is a good starter.
- Find out what they look like before hand
	- introducing yourself to the wrong person, or hesitating to say hello can lead to awkward introductions and failed first impression
	- secure a seat where you are visible and they can spot you in a crowd. 
	- leave information about how you will be dressed in an email or, attach a headshot to your networking email.
	- dont play the waving game or leave someone confused.
- Know how to pronounce thier name!
	- Go out of your way to pronounce thier name correctly by asking colleagues or asking them directly.
	- If it is difficult name, make sure you are sensitive to it and try not to butcher it. (apologetically if needed)
	- Some people have very first name sounding last names, that could trip anyone up. This is a mistake that can start the conversation on the wrong foot.
- Arrive with plenty of time, but just in case your late , apologize with confidence.
- Dress to impress, but dont over do it
	- bieng presentable doesnt mean wearing a suit and tie all the time. 
	- Think about a simple and professional outfit , it doesnt have to be a conversation piece
	- use appearance tp express discipline, and competance by doing things with detail
		- wash hair, trim finger nails, brush teeth, use lotion , etc.
		- hair cut, shave beard, trim nose, trim ears, etc. (before dressing)
		- breath mint , deodorant, cologne , etc.
		- Iron and wash your shirt,or blouse ; it doesnt have to be expensive to look clean , crisp and bright.
			-shirts withouts stains or rips, 
			- hem of pants are not ripped
			- Shirt and pants actually fit your body type
			- Belt that is new/clean without tears
		- Shoes, and jewelry, should be clean and polished
		- Shoes with "clean/new" shoelaces
		- Do not wear colors or patterns that are distracting or overbearing
		- Feel comfortable in your outfit
##### Small Talk 
- There are lots of books on how to communicate effectively, 
	- small talk is just bieng kind and embracing silent moments
	- use small talk to releive anxiety and humanize each other
	- do not force it, be honest when nervous because 
	- small talk chips away at any nervousness by creating conversation momentum
	- dont let it run away, you are there for a reason
	- instead of interrupting them intterupt yourself when spending to much time on small talk
		- "Speaking of..", "let me switch gears"
##### Ask/Listening
- Introductions
	- Most people ask about who you are , have your "condensend" background ready
	- dont tell them your resume (not enough time)
	- dont expand every detail (to much information)
	- dont overshare (not professional)
	- Create a simple 3 point intro to give them just enough  
		- "I used to work/study at " ... " I have been working on" ... "and I really like to " ....
- Clarify your expectations 
	- "I am looking for a new position in the company and i am interested in your department ..."
	- "I am trying to improve my networking skills by meeting leaders around the company ..."
	- "I am interested in pursuing my finance degree and would like to ask some questions about your field..."
- Ask interesting questions
	- ask the same intro questions if not already done so
		- "where did you work/study", "what is your current project/role", "what do you really like to do?"
	- the questions should be engaging to you and to them
	- the questions should be specific to them
		- if its a question anyone can answer generically in the same way its a waste of time
		- people want to feel special, and its your chance to show your interest in thier specific answer
		- frame questions specific to thier point of view
			- "As a newly appointed technology director, how did you handle the impact to your group after the dapartment made that change? "
- Dont make it an argument
	- do not take a stand on conterversial topics and have them argue the opposite side
	- be considerate of thier position
		- legal implications
		- public relations fallout
		- corporate rumors
		- ousting or calling out other leaders
		- any polorizing comments that can cause them to feel uncomfrotable
##### Take-away
- After actively listening, be sure to have take-waway questions that will anchor your interaction
- Example take-away questions to summarize the meeting
	- "What is your motto", "What is your lesson learned for me", "What is the key point to your success in one word"
- Ask for refrences/recommendations to other interesting people to talk to

##### The Follow Through
- Email a "thank you" note
- Follow up on any promises made during the meeting (like action items, or simple questions left unanswered)
- Keep in touch 
	- I let to much time pass before following up and those initial impressions do become dry if not watered, and can turn against you

#### Evolving my approach
- My list of questions evolved over time
	- be flexible and consider feedback to your approach
- Making my intentions clear
- Ditching the script
	- its good to be prepared but do not take any anxiety into a meeting and make someone feel uncomfortable
- Getting harsh feedback
	- When the harsh feedback comes, be ready to recieve it with interest and class
- Understanding personalities and how power can bend light
	- some personalities will be complex and interesting 
	- some personalities will be dull and underwhelming
	- always treat people with the same respect 
	- rely on your notes and preperation to invogorate a stale or awkward interaction
- Guiding my next engagement based on interest
- Finding a mentor I 'clicked' with
- Perfecting communication with confidence
#### Wisdom Gained
- Ice breakers (Everyone is interesting for 2 mins)
- High performers dont like to waste time
- Smart people like to hear thier own voice
- Lessons from thier life stories
- Observing who where the best communicators

- Impact it had on me
	- Opportunities given several times for employment
	- overcame fears of speaking with others
	- improved self confidence in communication
	- found a way to be independent and still lead by viewing the spectrum of leaders
	- some leaders seemed robotic, other seemed independent and creative
	- watched fear cripple and stunt growth of other engineers like me
	- embracing commercial skills made me less accepted by technical peers
	- networking become a necessity to carve out business value
	- went from "talking" and having "coffee" to undertanding the needs of other groups
	- by listenining to needs i was positioned to provide consulting
	- I was on the mind of directors as they positioned intiatiatives to place me in larger roles
	- I had to learn to take responsibility face to face
	- I learned to speak with authority over deadlines and commitment dates
	- I learned to defend projects and team members by clearing up confusion with customers and stakeholders over coffee
	- I was able to seek out good advice while dealing with conflicting situations 
	- Gained trust worthy contacts to help guide career decisions
	- Over the course of the networking experiment , i was offered 35% more money over the 2 years
		- bonus's , patents, and salary bumbs
	- I was able to recruit some great talent to my team
	- I was able to work with great teams across the comapny
	- I was brought into special projects that i would of never knew about unless i networked with the right people
	- I was able to connect others and create mentorship opportunities for other people
	- My work was appreciated more and received accolades from my peers and bosses
	- I was seen as someone that "brings" in valuable projects and not just completes them
	- I was asked to visit other teams and bring back information about what they needed
	- I was asked to help guide policy, and present feedback i received from influential customers
	- I was given an inside look into how people manage thier time, and tried to apply some techniques to my time
	- I was challenged to learn more about other departments
	- I became a better communicator, because i could sense 
	
	benefits:
	- inisghts into how leaders view , and  manage people and thier time
	- found a way to control my jobs outcome

meet people seehwats out there, and it come up as "kissing butt", side where you have to play a political game
in order ot be a part you need ot play a game. this "game" can throw people off, "dont want to PC", dont want to take crap to be accepted, 
- they want to be independent
- autonomous


Topic:
- from leader to "actor" , from military leader to hollywood influencer ; the evolution of some leaders to executive
- ethics of leaders betraying to employees?

people who fell into the role and other who wanted to run the show since day one. 

- do you regret going into management? 
- how do you compromize
- olr folks who see value who dont want to do it
- older folks who already went through it ,
- people who value it and cant put in the effort
- young engineers gorw up in this environment and tend to diminsih the value of networking earlyin the career
- some people have different stages in the career
- young people join odler team mates and think its not valuable to network or build a network
- Generational change ibrings a new paradigm
	- young kids saved the world every day in video games , why cant they do it at work
	- 




networking leads to a "control segment" to pivot career
- spending more time in leadership roles (meetings and etc.)
- women dont have the luxury to go home keep working on othre stuff..

director spokesperson for the business
- alotof people use it as a level for grading themselves
- measuring sucess outside of the corporate office 




#### Other
- Most interesting advice
- People dont know what to say
- NO one person has the right answer
- Conflicting styles
- Good/Bad leader
- View from the top is different than my peers



#### My Ideas on work thought
- Jack Welsh : A PhD in engineering and the best modern CEO of GE -   **[[PHD]]**
- Warrent Buffet : A humble stock investor using arithmetic and evaluations
- James Simons : Stock investor using advanced mathematics to build a lucrative hedgefund

- Trying to picture how ideas organize around decisions:

	- Raw data gathers around like a cloud
	- Data seems to condense inside the mind like water droplets in a thundercloud
	- Forces that mimic conductivity and gravity pull these droplets of condensed data
	- The droplet of data are pulled into water drops that crystalize in unique ways into snow flakes
	- These 2 dimensional shapes are created from the symmetry of the properties of each drop
	- The snowflakes can take these customshapes that can overlap in certain regions
	- They fall into a stackable tower made of pervious snowflakes thathave fallen and crystalized over each other as they joined like puzzles
	- These collumns of 2 dimensional crystalized data are continually growing actracting similar "snowflakes" to itself based on its uniqueproperties. It sometimes shifts as irregularities build over time. 
	- These collumns eventually grow until they are large and protruding, making them more accesible and attractive over time.
	- As these data collumns grow they create vertical channels as similar data shapes overlay each other with gaps in the shape. the vertical channels are areas that are unknown .
	- As these data shapes attract each other on edges ofhtesurface that are most dense the irregularities grow eventually attracting different data shets
	- the data collumns, become a stac of self organized data that is used as fibers 
	- over time these fibers grow and attract each other when the vertical alignment has polorized nearby fibers 
	- the intermingling of fibers creates larger stack of fibers with unique physical interactions that will cause folding of these structures in 3 dimensions
	- Even though the structure is in 3 dimensions the data sheets are still attracted to the end of the fibers only
	- This forces the "cloud and raindrop" analogy to take the form of conductivity and magnetisim over a 3 dimensional sapce like a point cloud hovering around folded fibers with attractive end nodes.
	- The crystalization of each of the condensed data drops either happens on the end of the node or before attaching itself.
	- The ionized channels would fold but the structures it creates as they attach to each other will, then build 3 dimensional structures that form ideas. the way data is organized in these structures would stem from self organized sheets of raw data compiling into similar data until those similarities become weighted in a polarized way forcing the observations of raw data to create "insights" the insights are still raw and do not have connections by itself. The connections of binding with other fibers is what creates patterns of insights that strengthen the previous insight
	- the insights then turn into ideas bybinding the structures into surfaces.
	- the surfaces are unique and suspended in space . The layers of surfaces can have neutral polarization but also can begine to create a "framework" by binding structures into geometric frameworks 
	- the frameworks setup a calcified network with protrusions . 
	- Initially the frameworks have cracks and over time they are stressed and forces are enacting onit based on external systems 
	- The frameworks are pushed on each side through "external forces"
	- the external forces come from the same pressures generated from the absorbtion of data into the "clouds" the forces are like waves, that grow in a particular direction based on permeation of data into the system as gas through osmosis
	- 

	Modeling this idea using a 2 dimensional view
	