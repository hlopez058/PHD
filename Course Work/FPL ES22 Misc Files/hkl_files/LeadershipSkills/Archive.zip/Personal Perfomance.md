| Week    	| Academic Reviews 	| Technical Work 	| Career Development 	| Plan Tommorow Today 	| Fight Throughs 	| Habits Stacking	| Attack Open Space 	|
|---------	|------------------	|----------------	|--------------------	|---------------------	|----------------	|--------	|-------------------	|
| 6/01/20 	|  5 |   3  |  4  |   5  |  5  | 4  | 5  |  
| 6/05/20 	|   4 |   2  |  4  |   3  |  3  | 2 | 2  | 
| 6/10/20 	|   3 |   2  |  3  |   2  |  2  | 2 | 1  |  
| 6/15/20 	|   3 |   2  |  3  |   2  |  2  | 2 | 1  | 







