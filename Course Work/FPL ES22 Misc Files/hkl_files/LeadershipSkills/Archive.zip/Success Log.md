I like that i was able to spend quality time with my family
I like the way i was able to keep the tomorrow plan today going for 2 weeks
I like the effort i made to win the fight throughs
I was able to identify when i had problems in effort and habits


I am happy with teh habit of watching a finance video
I am happy that i was able to complete the land permit

Explore/Exploit => Cast a wide net then shift focus to the best outcome. 
When winning exploit but when losing explore.

What feels like fun but work for others?
- Programming, Mathematical concepts, building creative apps
- designing a new system 

THe things that are natural to me:
- coming up with stories, and worlds about things that dont exist yet

You can win by bieng diffrent. Combine your skills to shotcut the need for genetic advantage. A great player creates a new game. 

Specialization overcomes genetics.

My environment is to create with my skills: 
- invetions, design, programming and building. 

Get better over time and get stronger over time with consistency. 

I want to build habits in :
- building
- writing stories
- drawing 
- juijitsu

Greatest threat to success is boredom. Derailing progress to seek novelty. 


Organization of work
Managed to plan 3 things before the next day and complete it every day so far. 
Woke up this morning (5/28) and hit the top 3 tasks , 
- spoke to myself 
- won the fightthrough
- avoided distraction when pinged by coleauge



Week 6/5
- I was able to stay on track even when all of myhabits where out of controlled by winning the fight throughs
- I remained calm and prepared during my scrum meetings

