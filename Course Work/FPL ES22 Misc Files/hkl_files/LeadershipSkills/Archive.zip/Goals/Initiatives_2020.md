## FPLES IT GOALS:
- Implement Technology solutions to sell, service and bill new businesses Leasing and Whole Home Florida
- Provide tools to manage customers and operations for the Backup Generator Business.
- Build right-sized yet scalable capabilities for Gulf Power Surge Shield and Commercial Lighting programs.
- Optimize existing technology solutions to meet net income targets for National Whole Home Warranty, SurgeShield, Electronic Surge Protection and Residential Services
- Deliver Improved analytics that enable faster, more confident data-driven busines decisions along with customer insights that drive returns
- Improve internal team effectiveness by filing key open positions leveraging more agile pracitces and piloting test automation.

---

### Solutions for Whole Home & Leasing 
> Goal : Implement Technology solutions to sell, service and bill new businesses Leasing and Whole Home Florida
Comment: Refocus the goal and frame it so that the focus is identifying the barriers in the following categories for the 
distinct domains:
- Sales 
- Service
- Billing
Are these barriers because of current processes? Can we simplify, current processes in order to optimize? Will the simplification
be a process change or an implementation of technology like automation?


### Backup Generator Business Customer Management
- Provide tools to manage customers and operations for the Backup Generator Business.
How does the business manage customers today?
What KPI can be used to determine sucess when managing customers?
How could automation or data anlytical insights assist in managing customer data?
Is customer organization, intellectual property, privacy concerns or relationship management the problem?


### Scalable Capabilities for Core Business
- Build right-sized yet scalable capabilities for Gulf Power, Surge Shield and Commercial Lighting programs.
What are commercial business needs?
What is surge shireld trying to do? how can they be helped? 
Are the core business in need of data warehouses? like redshift?
the commercial lighting program needs to be assessed

### Core Business Technology Soltuion Optimization 
- Optimize existing technology solutions to meet net income targets for National Whole Home Warranty, SurgeShield, Electronic Surge Protection and Residential Services
What are the core technologies in place today?
CRM for salesforce and Microsoft Dynamics AX. 
What are the custom applications and what is the technical debt?


### Data Analytics Platform 
- Deliver Improved analytics that enable faster, more confident data-driven 
busines decisions along with customer insights that drive returns
What are the return KPI's that we can measure against?
What insights are the business customers valued?
Merger of data and analytics into a common platform?

### Building A Team
- Improve internal team effectiveness by filing key open positions leveraging more 
agile pracitces and piloting test automation.
Identify key enabler skills, and find people who can assimilate into a startup culture



Products: 
- Nextera Whole Home Warranty
- 