## Plan for Month

### Technical:
- Released Data Int. Platform Beta 
- Release a Salesforce Interactive Map to production
- Run The Business : 
	- Submit Digi Assistant for funding 
	- Hand over all Salesforce tasks to Anikit

### Networking:
- Networking with Jim Gill, Barr Moses and Jim Robo
- Codecamp Lesson 2 
- Complete LDF lesson 2

### Financial:
- Personal Finances
	- Submit Taxes for 2020
	- Learn financial terms in order to manage the metrics
	- Create an actionalble financial portfolio

### Academic:
- PHD review of 33 papers
- PHD secure a council member from work


## Daily Process Plan
- 2 hours on technical tasks
- 15 mins on networking preperations
- 15 mins on financial reviews
- 30 mins on academic research





## Week 1:
### Technical
- DIP Beta
	- Run Streamsets on computer in the office ( Salesforce data to DWH , and AX data to DWH needs to fully replicated)
	- Event based record reads need to be tested
	- Sample report should be made that can validate data off DWH

### Networking:
- Review Nextera Investor report for Q1 2020
- Mental Prep questions for talk with Jim Robo , Jim Gill, Barr Moses
- Research online the businesses of each mentor

### Academic:
- Review of 5 papers with summaries
- Submit a Recommendation paper for Dr.Z by tuesday

## Day 1
- DIP: Run Streamsets on computer in the office ( Salesforce data to DWH , and AX data to DWH needs to fully replicated)
- DIP: Event based record reads need to be tested, create sampe report to connect to it
- Define questions for technical and send to troy for review
- complete read of phd paper and create a write up
## Day 2
- DIP: Event based record reads need to be tested, create sampe report to connect to it
x- complete read of phd paper and create a write up
- Prep for salesforce meeting, invite anikt. Prep for DIP and for metric meeting
## Day 3
- DIP: Event based record reads need to be tested, create sampe report to connect to it
- gather new paper and begin reading, complete review for thrusday
-reach out to miguel and get digi assistatn funding
## Day 4
- DIP: Event based record reads need to be tested, create sampe report to connect to it
- gather new paper and begin reading, complete review for thrusday
-reach out to miguel and get digi assistatn funding


## Backlog
[[TODO]] incorporate feedback from cesar into presentation to refine the story
[[TODO]] set meeting with sybil to design nat gas metrics
[[TODO]] send questions to troy fo rjim robos meeting
[[TODO]]	Read book 21 irrefutale lessones of leadership by johnm maxwell
[[TODO]] call google forrefund